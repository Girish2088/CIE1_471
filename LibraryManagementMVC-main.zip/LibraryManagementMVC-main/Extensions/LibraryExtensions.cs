namespace LibraryManagementMVC.Extensions;

public static class LibraryExtensions
{
    public static string GetDueStatus(this LibraryMember member)
    {
        if (member.IsReturned)
            return "Returned";

        if (!member.ReturnDate.HasValue)
            return "Issued";

        DateTime today = DateTime.Today;
        DateTime returnDate = member.ReturnDate.Value.Date;

        if (returnDate < today)
            return "Overdue";
        else if ((returnDate - today).TotalDays <= 3)
            return "Due Soon";

        return "Issued";
    }

    public static decimal CalculateFine(this LibraryMember member)
    {
        if (member.IsReturned || !member.ReturnDate.HasValue)
            return 0;

        DateTime today = DateTime.Today;
        DateTime returnDate = member.ReturnDate.Value.Date;

        if (today > returnDate)
        {
            int overdueDays = (today - returnDate).Days;
            return overdueDays * 10; // ₹10 per overdue day
        }

        return 0;
    }
}