namespace LibraryManagementMVC.Controllers;

public class LibraryController : Controller
{
    private static List<Book> _books = new List<Book>
    {
        new Book { BookId = 101, Title = "ASP.NET Core in Action", Author = "Andrew Lock", Category = "Programming", Price = 850, AvailableCopies = 5 },
        new Book { BookId = 102, Title = "Clean Code", Author = "Robert C. Martin", Category = "Software Engineering", Price = 950, AvailableCopies = 3 },
        new Book { BookId = 103, Title = "C# 12 and .NET 8", Author = "Mark J. Price", Category = "Programming", Price = 1100, AvailableCopies = 4 }
    };

    private static List<LibraryMember> _members = new List<LibraryMember>
    {
        new LibraryMember { MemberId = 1, MemberName = "Rahul Sharma", Department = "Computer Science", Email = "rahul@example.com", BookId = 101, IssueDate = DateTime.Today.AddDays(-10), ReturnDate = DateTime.Today.AddDays(-2), IsReturned = false },
        new LibraryMember { MemberId = 2, MemberName = "Priya Patel", Department = "IT", Email = "priya@example.com", BookId = 102, IssueDate = DateTime.Today.AddDays(-3), ReturnDate = DateTime.Today.AddDays(2), IsReturned = false }
    };

    public IActionResult Index()
    {
        ViewBag.Books = _books;
        return View(_members);
    }

    [HttpGet]
    public IActionResult IssueBook()
    {
        ViewBag.Books = _books;
        return View();
    }

    [HttpPost]
    public IActionResult IssueBook(LibraryMember member)
    {
        if (ModelState.IsValid)
        {
            member.MemberId = _members.Count > 0 ? _members.Max(m => m.MemberId) + 1 : 1;
            _members.Add(member);
            return RedirectToAction("Index");
        }

        ViewBag.Books = _books;
        return View(member);
    }

    public IActionResult BookDetails(int id)
    {
        var member = _members.FirstOrDefault(m => m.MemberId == id);
        if (member == null)
            return NotFound();

        var book = _books.FirstOrDefault(b => b.BookId == member.BookId);
        ViewBag.Book = book;

        return View(member);
    }

    public IActionResult About()
    {
        return View();
    }
}