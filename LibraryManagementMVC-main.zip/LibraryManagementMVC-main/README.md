<img width="1366" height="741" alt="Screenshot from 2026-09-03 15-14-29" src="https://github.com/user-attachments/assets/5a86ef7c-d4f0-477b-af24-9123eb250888" />
<img width="1366" height="741" alt="Screenshot from 2026-09-03 15-14-52" src="https://github.com/user-attachments/assets/f8bf5661-e31d-4235-bfb7-8cc8a90ef9ab" />
<img width="1366" height="741" alt="Screenshot from 2026-09-03 15-15-34" src="https://github.com/user-attachments/assets/69448623-9f8a-4afc-ad86-29d26e14a370" />

