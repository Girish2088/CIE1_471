namespace LibraryManagementMVC.Models;

public class LibraryMember
{
    public int MemberId { get; set; }

    [Required(ErrorMessage = "Member Name is required")]
    public string MemberName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Department is required")]
    public string Department { get; set; } = string.Empty;

    [Required(ErrorMessage = "Email is required")]
    [EmailAddress(ErrorMessage = "Invalid Email Address")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Please select a Book")]
    public int BookId { get; set; }

    [Required(ErrorMessage = "Issue Date is required")]
    [DataType(DataType.Date)]
    public DateTime IssueDate { get; set; } = DateTime.Today;

    [DataType(DataType.Date)]
    public DateTime? ReturnDate { get; set; }
    
    public bool IsReturned { get; set; } = false;
}